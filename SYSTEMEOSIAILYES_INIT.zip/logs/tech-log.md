# Journal technique initial

- 2025-09-09 : Création de la structure initiale SYSTEMEOSIAILYES
- Dépôt prévu sur GitHub (milyes)
- Première capsule : 001_intro.txt
